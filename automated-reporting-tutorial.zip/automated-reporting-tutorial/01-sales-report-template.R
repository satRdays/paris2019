# =================================================================================================
# = Simple Sales Report                                                                           =
# =================================================================================================

# Transform this script into a Markdown report.

# [ ] YAML header.
#
# ---
# title: "Simple Sales Report"
# output: html_document
# ---

# [ ] Chunk options.
#
# - echo = FALSE    (whether to include source code input in document)
# - include = TRUE  (whether to include source code output in document)

XLSX_PATH = file.path("data", "widget-sales-summary.xlsx")

library(knitr)
library(readxl)
library(ggplot2)

# [ ] Load data.
# 
# 1. Read data from XLSX file.
# 2. Label the chunk "load_data".
#
sales <- read_xlsx(XLSX_PATH)

# Take a look at the data.
#
head(sales)

# [ ] Timestamp sentence.
# 
# Create a sentence like:
#   
# "This is the sales report generated at 15:26 SAST 22 February 2019."
# 
# It should use the current date and time.
#
# Functions you might use:
#
# - Sys.time() and
# - strftime() or format().

# * Sales table
#
# [ ] "Sales Table" section heading.
# [ ] Paragraph text: "Below is a table with the total number of units sold per product."
# [ ] Format sales data as a table with caption "Total units sold per product". Use kable(). 

# * Sales figure
#
# [ ] "Sales Chart" section heading.
# [ ] Paragraph text: "Here is a chart with the same data."
#
# [ ] Plot a bar chart of total sales per product.
# [ ] Scale the y-axis values by one million.
# [ ] Fill the bars with colour "#3498db".
# [ ] Label the x-axis "product" and the y-axis "units sold / million".
# [ ] Set the plot title to "Total units sold".
#
ggplot(sales, aes(x = widget, y = count)) +
  geom_col()

# * Does it generalise?
#
# Edit the spreadsheet and
#
# [ ] change one of the values in the count column
# [ ] add a new product.
#
# Does the report still build?