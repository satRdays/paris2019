# =================================================================================================
# = Sales Report                                                                                  =
# =================================================================================================

# Transform this script into a Markdown report.

# [ ] YAML header.
#
# ---
# title: "Sales Report"
# output:
#   html_document:
#     self_contained: yes
# editor_options: 
#   chunk_output_type: inline
# ---

# [ ] Chunk options.
#
# - echo = FALSE
# - message = FALSE
# - fig.width = 10

# [ ] Create a code chunk. Call it 'load_libraries'.
#
library(knitr)
library(readxl)
library(dplyr)
library(purrr)
library(tidyr)
library(lubridate)
library(ggplot2)
library(scales)
library(countrycode)

# [ ] Create a code chunk. Call it 'load_data'.
# [ ] Define path to data file.
#
# - Open the XLSX in your spreadsheet software.
# - Consider what would be required to analyse these data.
#
XLSX_PATH = file.path("data", "widget-sales-subset.xlsx")

# Iterate over multiple sheets and concatenate into a single table.
#
# [ ] Use excel_sheets() to get names of tabs.
# [ ] Iterate over the tabs.
#
#     - Load each into a data frame.
#     - Use map() or map_dfr() from purrr or go old school with lapply().
#     - Assign result to 'sales'.
#
# [ ] Add a "widget" column with the tab (product) name. Do this while iterating?
# [ ] Convert the time column to a Date type.
# [ ] Pivot the data so that it is in "long" format.
#
#     - Use gather() from tidyr.
#
# The final data should look like this:
#
#   date       widget country count
# 1 2018-01-01 A      FRA       191
# 2 2018-01-02 A      FRA       270
# 3 2018-01-03 A      FRA       240
# 4 2018-01-04 A      FRA       233
# 5 2018-01-05 A      FRA       232
# 6 2018-01-06 A      FRA       284
#
# The beauty of this code is that it's able to handle an arbitrary number of sheets.
#
# - Add a sheet, the code will still work.
# - Remove a sheet, ditto.
#
sales <- NULL

# Add in a column with country names.
#
# In Excel this would probably be done using a VLOOKUP.
#
sales <- sales %>%
  rename(country_code = country) %>%
  mutate(
    country_name = countrycode(country_code, "iso3c", "country.name")
  ) %>%
  select(date, country_code, country_name, everything())

# [ ] Explanatory sentence
#
# "The number of widgets sold per month are recorded in the table below."

# * Monthly sales table
#
# [ ] Find the number of widgets sold per month.
# [ ] Use kable() to render a table showing the number of widgets sold per month.
#
#     The table should have
#
#     - a year column
#     - a month column and
#     - a column for each product.
#
sales %>%
  mutate(
    year = year(date),
    month = month(date, label = TRUE, abbr = FALSE)
  ) %>%
  group_by(year, month, widget) %>%
  summarise(
    count = sum(count)
  ) %>%
  spread(widget, count)

# * Weekly sales numbers.
#
# [ ] Prepare weekly summary.
# [ ] Which was the best week?
#
sales_weekly <- sales %>%
  mutate(
    week_number = isoweek(date),
    dow = wday(date, label = TRUE)
  ) %>%
  group_by(week_number, widget) %>%
  summarise(
    date = min(date),
    count = sum(count)
  )
#
sales_weekly_best <- sales_weekly %>%
  group_by(date) %>%
  summarise(count = sum(count)) %>%
  arrange(desc(count)) %>%
  slice(1)

# [ ] Best week sentence.
# 
# Create a sentence like:
#   
# "The best week was 24 December 2018, when 498089 widgets were sold."
# 
# The week and the number of widgets should be derived from the data.

# [ ] Plot sales per week per product.
#
ggplot(sales_weekly, aes(x = date, y = count / 1000)) +
  geom_line(aes(colour = widget)) +
  scale_x_date(date_breaks = "1 month", date_labels = "%b") +
  scale_y_log10() +
  labs(x = "", y = "Units / thousand") +
  ggtitle("Weekly Sales")

# * Country sales numbers.
#
# [ ] Aggregate sales by country.
# [ ] Sum over products.
# [ ] Rank countries by total sales.
#
country_sales <- sales %>%
  group_by(country_code, country_name, widget) %>%
  summarise(count = sum(count))
#
country_sales_total <- country_sales %>%
  group_by(country_name) %>%
  summarise(count = sum(count)) %>%
  arrange(desc(count))
#
country_sales_ranking <- country_sales_total %>% pull(country_name)

# [ ] Best countries sentence.
# 
# Create a sentence like:
#   
# "The highest sales volume was recorded in United Kingdom, followed by South Africa."
#
# The countries should be derived from the data.

# * Total sales by country.
#
ggplot(country_sales_total, aes(x = country_name, y = count / 1000000)) +
  geom_col() +
  labs(x = "", y = "Units / million") +
  ggtitle("Sales by Country") +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5),
    axis.text.y = element_text(angle = 90, hjust = 0.5)
  )

# [ ] Explanatory sentence.
#
# "The chart below shows how sales are broken down by product and country. The proportions are normalised per country."

# * Sales by product and country (normalised per country).
#
sales %>%
  group_by(country_name, widget) %>%
  summarise(
    count = sum(count)
  ) %>%
  # Data are still grouped by country_name.
  mutate(
    # Normalise per country.
    frac = count / sum(count)
  ) %>%
  ggplot(aes(x = country_name, y = widget)) +
  geom_raster(aes(fill = frac)) +
  geom_text(aes(label = sprintf("%.1f%%", frac * 100))) +
  labs(x = "", y = "Product") +
  ggtitle("Product proportions per country") +
  scale_fill_gradient("", low = "white", high = "#27ae60", labels = percent, limits = c(0, 1)) +
  theme(
    axis.text.x = element_text(angle = 90, hjust = 1, vjust = 0.5)
  )

# [ ] Explanatory sentence.
#
# "This is a complimentary view in which proportions are normalised per product."

# * Sales by product and country (normalised per product).
#
# [ ] Replicate summary data (previous plot) but reverse order of group_by().
# [ ] Normalise will now be "per widget".
# [ ] Generate plot with colourscale from white to "#2980b9".
# [ ] Set the plot title to "Country proportions per product".

# * Table styling.
#
# [ ] Load the kableExtra library.
#
# Try these styling options:
#
# [ ] Try piping into kable_styling(bootstrap_options = c("striped", "hover")).
# [ ] Add the "condensed" option for a more compact table.
# [ ] The table does not need to be full width. Try full_width = FALSE.
# [ ] Try position = "left".
#
# There are lots of other options for pimping your tables.
#
# Check out https://cran.r-project.org/web/packages/kableExtra/vignettes/awesome_table_in_html.html.

# * ggplot2 theme
# 
# [ ] Load the hrbrthemes library.
# [ ] Use theme_set() to set the default theme to theme_ipsum_rc() with a grid on y-axis.
# [ ] Try option: grid = "Y".

# * Expanded dataset
# 
# [ ] Use the "widget-sales.xlsx" data (more products and more countries).
# [ ] Note that the report still works!!